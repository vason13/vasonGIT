/*
 * DA3.c
 *
 * Created: 3/30/2018 11:08:13 AM
 * Author : vince
 */ 


#define F_CPU  16000000UL		//set clock at 16MHz
#define BAUD 9600				//set baud rate of 9600
#define MYUBRR F_CPU/16/BAUD-1	


#include <avr/io.h>				//include necessary libraries
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>

void adc_init(void);			//declare a void function that will initialize the ADC
void read_adc(void);			//declare a void function that will read the ADC
void USART_tx_string(char*data);	//declare a void function that will print the temperature
void USART_init(unsigned int ubrr);		//declare a void function that will initialize USART

volatile unsigned int adc_temp;		//declare a changing variable that will hold the temperature value 
char outs[20];						//declare an array of characters with size 20

int main(void)
{
	adc_init();				//call the adc_init function to initialize the ADC
	USART_init(MYUBRR);		//call the USART_init function and pass MYUBRR to it
	USART_tx_string("Reading Temperature:\r\n");	//pass the string "Reading Temperature:" and print it on the visualizer
	_delay_ms(125);			//wait for 125 ms
	sei();					//set interrupt enable, every time timer1 overflows, we execute the ISR

	while(1)
	{
		
	}
}

void adc_init(void)		//this function is responsible for setting up and enabling the ADC
{
	/*
	The line below sets each bit of the ADMUX register.
	(0<<REFS1) and (1<<REFS0) sets the refrence voltage. Uses AVcc with external capacitor at AREF pin.
	(0<<ADLAR) is to shift the ADC result to the right 
	(1<<MUX1) | (1<<MUX0) sets the single ended input as ADC3. connect the middle pin of the LM34 to PC3
	*/
	ADMUX = (0 << REFS1) | (1<<REFS0) | (0<<ADLAR) | (1<<MUX1) | (1<<MUX0);
	
	/*
	The line below sets each bit of the ADSCRA register
	(1<<ADEN) is for enabling the ADC
	(0<<ADSC) ADC start conversion
	(0<<ADATE) Disable auto triggering of the ADC
	(0<<ADIF) set ADC interrupt flag to 0
	(0<<ADIE) set ADC interrupt enable to 0
	(1<<ADPS2)  (0<<ADPS1)  (1<<ADPS0) set ADC prescaler to 32
	*/
	ADCSRA = (1<<ADEN) | (0<<ADSC) | (0 << ADATE) | (0<<ADIF) | (0<<ADIE) | (1<<ADPS2)| (0<<ADPS1) | (1<<ADPS0);
	
	TIMSK1 |= (1<<TOIE1);			//enable Timer1 overflow interrupt
	TCCR1B |= (1<<CS12) | (1<<CS10);	//set timer prescale to 1024
	TCNT1 = 49911;		//set TCNT value. Calculated using 65535 - (16MHz/1024-1)
}

void read_adc(void)		//this function is responsible for reading the ADC pins 
{
	
	unsigned char i=4;	//declare how many times we will measure temperature per average
	adc_temp=0;			//initialize adc_temp to 0
	while(i--)			//while i != 0, keep looping
	{
		
		ADCSRA |= (1<<ADSC);		//start the first conversion 
		while(ADCSRA & (1<<ADSC));	//while ADCSRA and 1 is written to ADSC, keep looping
		adc_temp+=ADC;			//sum the ADC values 
		_delay_ms(50);			//wait for 50 ms
	}
	adc_temp = adc_temp /4;		//take the average of the measured temperatures 
}

void USART_init(unsigned int ubrr)		//this function is responsible for initializing USART (RS-232)
{
	UBRR0L = (unsigned char)ubrr;
	UBRR0H = (unsigned char)(ubrr>>8);	
	UCSR0B = (1<<TXEN0);			//enable the USART Transmitter
	UCSR0C = (3<<UCSZ00);			//sets the number of data bits in a frame the receiver and transmitter use
}

void USART_tx_string(char*data)		//function responsible for printing the temperature
{
	while((*data != '\0'))			//check if the character being read is = '\0' if it is equal stop looping
	{
		while(!(UCSR0A & (1<<UDRE0)));
		UDR0 = *data;
		data++;					//increment data 
	}
}

ISR(TIMER1_OVF_vect)
{
	read_adc();					//get the temperature 
	snprintf(outs,sizeof(outs), "%3d Fahrenheit\r\n", adc_temp);	//store the temperature into a string of 20 characters 
	USART_tx_string(outs);		//print the temperature 
	TCNT1 = 49911;				//reset the timer for next iteration 
}



