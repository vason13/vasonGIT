
#define F_CPU  16000000UL		//set clock at 16MHz
#define BAUD 9600				//set baud rate of 9600
#define MYUBRR F_CPU/16/BAUD-1	

#include <avr/io.h>				//include necessary libraries
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>

void adc_init(void);			//declare a void function that will initialize the ADC
void read_adc(void);			//declare a void function that will read the ADC
void USART_tx_string(char*data);	//declare a void function that will print the raw pulse and BPM
void USART_init(unsigned int ubrr);		//declare a void function that will initialize USART

volatile unsigned int heart_rate;		//declare a changing variable that will hold the heart rate value 
volatile unsigned int BeatsPerMinute;
volatile unsigned int timeElapsed;
char outs[20];						//declare an array of characters with size 20
char printMe[20];
int Threshold = 400;				//variable to compare the value read from the sensor
int timeVariable = 60;				//variable to hold 60 seconds

int main(void)
{
	DDRB = 0xFF;
	adc_init();				//call the adc_init function to initialize the ADC
	USART_init(MYUBRR);		//call the USART_init function and pass MYUBRR to it
	USART_tx_string("Reading:\r\n");	//pass the string "Reading:" and print it on the visualizer
	_delay_ms(125);			//wait for 125 ms
	sei();					//set interrupt enable, every time timer1 overflows, we execute the ISR

	while(1)
	{
		
	}
}

void adc_init(void)		//this function is responsible for setting up and enabling the ADC
{
	/*
	The line below sets each bit of the ADMUX register.
	(0<<REFS1) and (1<<REFS0) sets the refrence voltage. Uses AVcc with external capacitor at AREF pin.
	(0<<ADLAR) is to shift the ADC result to the right 
	(1<<MUX1) | (1<<MUX0) sets the single ended input as ADC3. connect the middle pin of the LM34 to PC3
	*/
	ADMUX = (0 << REFS1) | (1<<REFS0) | (0<<ADLAR) | (1<<MUX1) | (1<<MUX0);
	
	/*
	The line below sets each bit of the ADSCRA register
	(1<<ADEN) is for enabling the ADC
	(0<<ADSC) ADC start conversion
	(0<<ADATE) Disable auto triggering of the ADC
	(0<<ADIF) set ADC interrupt flag to 0
	(0<<ADIE) set ADC interrupt enable to 0
	(1<<ADPS2)  (0<<ADPS1)  (1<<ADPS0) set ADC prescaler to 32
	*/
	ADCSRA = (1<<ADEN) | (0<<ADSC) | (0 << ADATE) | (0<<ADIF) | (0<<ADIE) | (1<<ADPS2)| (0<<ADPS1) | (1<<ADPS0);
	
	TIMSK1 |= (1<<TOIE1);			//enable Timer1 overflow interrupt
	TCCR1B |= (1<<CS12) | (1<<CS10);	//set timer prescale to 1024
	TCNT1 = 49911;		//set TCNT value. Calculated using 65535 - (16MHz/1024-1)
}

void read_adc(void)		//this function is responsible for reading the ADC pins 
{
	
	unsigned char i=4;	//declare how many times we will measure raw pulse per average
	heart_rate=0;			//initialize heart_rate to 0
	while(i--)			//while i != 0, keep looping
	{
		
		ADCSRA |= (1<<ADSC);		//start the first conversion 
		while(ADCSRA & (1<<ADSC));	//while ADCSRA and 1 is written to ADSC, keep looping
		heart_rate+=ADC;			//sum the ADC values 
		_delay_ms(50);			//wait for 50 ms
	}
	heart_rate = heart_rate /4;		//take the average of the measured pulse sensor values
}

void USART_init(unsigned int ubrr)		//this function is responsible for initializing USART (RS-232)
{
	UBRR0L = (unsigned char)ubrr;		//set baud rate of 9600
	UBRR0H = (unsigned char)(ubrr>>8);	
	UCSR0B = (1<<TXEN0);			//enable the USART Transmitter
	UCSR0C = (3<<UCSZ00);			//sets the number of data bits in a frame the receiver and transmitter use
}

void USART_tx_string(char*data)		//function responsible for printing the raw pulse and BPM
{
	while((*data != '\0'))			//check if the character being read is = '\0' if it is equal stop looping
	{
		while(!(UCSR0A & (1<<UDRE0)));
		UDR0 = *data;
		data++;					//increment data 
	}
}

ISR(TIMER1_OVF_vect)
{
	timeElapsed = timeElapsed + 1;
	read_adc();					//get the pulse
	if(heart_rate > Threshold)	//If the ADC value that was read is greater than the threshold, print the raw pulse
	{
	BeatsPerMinute = BeatsPerMinute + 1; //increment the Heart Beat counter
	snprintf(outs,sizeof(outs), "%3d Raw Pulse\r\n", heart_rate);	//store the raw pulse into a string of 20 characters 
	USART_tx_string(outs);		//print the pulse 
	PORTB = 0xFF;			//turn on LED every time a raw pulse is recorded
	_delay_ms(50);			//wait for 50 ms
	PORTB = 0;				//turn off the LED 
	TCNT1 = 49911;			//reset the timer for next iteration 
	
		if(timeElapsed == timeVariable)	//if the timeElapsed is equal to 60 seconds, print the Number of Beats
		{
		snprintf(printMe,sizeof(printMe), "%3d BPM\r\n", BeatsPerMinute);	//store the raw pulse into a string of 20 characters
		USART_tx_string(printMe);		//print the BPM
		timeElapsed = 0;			//reset the time elapsed
		BeatsPerMinute  = 0;		//reset the number of beats 
		}
	
	}
	//If the ADC value that was read is less than the threshold, the pulse is not legitimate. Most likely due to noise.
	else
	{
		TCNT1 = 49911;		//reset the timer for next iteration
	}
}

