/*
 * Asst2Task1.c
 *
 * Created: 3/12/2018 2:21:49 PM
 * Author : vince
 */ 

#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
	DDRB |= (1<<PB2);		//set PB2 as an output

    while (1) 
    {
		PORTB |= (1<<PB2);	//Turn PB2 On
		_delay_ms(250);		//wait for 250ms
		PORTB &= ~(1<<PB2);	//Turn PB2 Off
		_delay_ms(250);		//wait for 250ms 
    }
	return 1;
}

