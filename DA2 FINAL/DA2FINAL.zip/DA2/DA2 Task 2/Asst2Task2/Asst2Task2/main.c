/*
 * Asst2Task2.c
 *
 * Created: 3/12/2018 4:02:14 PM
 * Author : vince
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
    DDRB = (1<<PB2);	//set PB2 as an output
	DDRD = 0x00;		//set all bits of DDRD to 0
	 
    while (1) 
    {
		if((PIND&0x04)==0x04)	//if PD2 is changes execute instructions else stay off
		{
			PORTB = 0xff;		//Turn PB2 on
			_delay_ms(1000);	//wait for 1 second then turn off
		}
			
		else
			PORTB = 0x00;		//turn PORTB off
    }
	
	return 0;
}

