/*
 * Task5Ccode.c
 *
 * Created: 3/14/2018 4:16:02 PM
 * Author : vince
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
ISR(INT0_vect)
{
		PORTB = 0x04;		//turn PB2 on
		_delay_ms(1000);	//wait for 1 second
		PORTB = 0x00;		//turn PB2 off
}

int main(void)
{
	EIMSK = 0x01;		//Enable External Interrupt 0
	EIFR = 0x01;		//Enable External Interrupt Flag Request 0
	EICRA = 0x03;		//Rising edge of Int0 generates an interrupt request
	sei();				//Enable 'I' Bit in status register
	DDRB = 0xFF;		//set all bits in DDRB to 1
	
	while (1)			//poll for an event
	{
	
	}
	return 0;
}


