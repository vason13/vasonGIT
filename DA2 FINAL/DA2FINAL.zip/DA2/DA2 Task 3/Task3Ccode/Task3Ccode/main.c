/*
 * Task3Ccode.c
 *
 * Created: 3/14/2018 3:47:14 PM
 * Author : vince
 */ 

#include <avr/io.h>


int main(void)
{
	DDRB = 0x04;		//set pb2 as an output
	TCCR0A = 0x02;		//set CTC mode
	TCCR0B = 0x05;		//prescale 1024
	TCNT0 = 0x00;		//initialize timer 0 to 0
	OCR0A = 64;			//continously compared to timer 0
	
	
	while (1)
	{
		if(TIFR0 & (1 << OCF0A))	//if there is an overflow
		PORTB ^= 0x04;			//turn pb2 on
		TIFR0 |= (1 << OCF0A);	//clear flag
	}
}

