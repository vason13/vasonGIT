/*
 * DCmotor.c
 *
 * Created: 4/9/2018 1:13:10 PM
 * Author : tuasov1
 */ 

#include <avr/io.h>				//include the libraries
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
int count = 0;			//variable to keep track if motor should be on or off

int main(void)
{
	DDRD |= (1<<PORTD6);		//initializes PD6 as output
	DDRB |= (1<<PORTB1);		//initializes PB1 as output
	
	TCCR0B = 1;		//no prescale
	TCCR0A = 0x83;  //fast PWM
	
	
	EIMSK = 0x01;		//Enable External Interrupt 0
	EIFR = 0x01;		//Enable External Interrupt Flag Request 0
	EICRA = 0x03;		//Rising Edge of INT0 generates an interrupt request
	sei();
	ADMUX = 0x60;		//set channel to take input for ADC0, left adjust, AVcc with external cap at AREF
	ADCSRA = 0xe6;		//enable ADC< start conversion, enable ADC auto trigger, division factor 64
	
	while(count = 1)
	{
		ADCSRA |=(1<<ADSC);		//start conversion
		while((ADCSRA&(1<<ADIF))==0);	//wait for conversion to finish
		OCR0A = ADCH;			//set OCR0A equal to ADCH
	}
	
	return 0;
}

ISR(INT0_vect)
{
	
	if(count == 0)			//since count was initialized to 0, execute if
	{
		PORTB |= (1<<PORTB1);	//enable chip
		_delay_ms(1000);		//wait for 1s
	}
	
	else
	{
		PORTB &= ~(1<<PORTB1);	//disable L293D
		_delay_ms(1000);		//wait for 1s
	}
	
	count ^= 1;		//xor 0 with 1, we come out with 1, now if the button is pressed again the motor should execute else, and turn off the motor
	
}