/*
 * ServoMotor.c
 *
 * Created: 4/11/2018 12:31:52 PM
 * Author : tuasov1
 */ 
#define F_CPU 1000000UL		//CPU frequency of 1MHz
#include <avr/io.h>
#include <util/delay.h>
int  whatPosition = 0;		//variable to hold ADC value
int main(void)
{

	DDRD = 0xFF;			//Initializes Port D as output.
	TCCR0B=3;				//64 prescalar.
	TCCR0A=0x83;			//Clear OC0A on compare match. Fast PWM
	ADMUX = 0x60;			//use channel ADC0, Left Adjust, AVcc
	ADCSRA = 0xe6;
	while (1)
	{
		ADCSRA |= (1<<ADSC);	//start conversion
		while((ADCSRA&(1<<ADIF))==0);	//wait for conversion to finish
			whatPosition = ADCH;		//set variable whatPosition equal to ADCH
			
		if(whatPosition == 0)			//minimum value of ADCH polled from potentiometer is 0, places servo at 0 degrees
		{	
			OCR0A = 0;					//0 Degrees
			_delay_ms(500);				//wait for 500 ms
		}
		else if(whatPosition == 255)	//max value of ADCH polled from potentiometer is 255 since we are using an 8 bit timer
		{								//255 is reached when the potentiometer reaches 5V 
			OCR0A = 30;					//180 Degrees
			_delay_ms(500);				//wait for 500 ms
		}
		else;							//if whatPosition is not equal to min or max, then do nothing
	}
}
