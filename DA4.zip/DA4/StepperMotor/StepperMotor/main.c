/*
 * StepperMotor.c
 *
 * Created: 4/10/2018 8:59:45 PM
 * Author : vince
 */ 

#define F_CPU 1000000UL		//include the libraries
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

volatile uint8_t velocity;	//variable to hold the new top value 

int main(void)
{

	DDRB = 0xFF; //set port B as output
	ADMUX = 0b01000000; //AVcc with external capacitor at AREF pin, use PC0(ADC0) channel
	ADCSRA = 0b10001110; //enable adc, enable ADC interrupt, division factor of 64	
	sei();		//set enable interrupt
	
	while(1)
	{
		PORTB = 0x66;		//moves the motor
		get_delay();		//set a delay based on ADC
		PORTB = 0xCC;		//moves the motor
		get_delay();		//set a delay based on ADC
		PORTB = 0x99;		//moves the motor
		get_delay();		//set a delay based on ADC
		PORTB = 0x33;		//moves the motor
		get_delay();		//set a delay based on ADC
	}
	
}

void get_delay(void)
{
	TCNT0 = 0;					//set TCNT to 0
	OCR0A = velocity;			//set top value to velocity
	TCCR0A |= (1 <<COM0A0);		//toggle OC0A on compare match
	TCCR0B |= ( 1<< WGM02) | (1 << CS02) | (1<< CS00); //CTC mode, 64 prescale
	while((TIFR0 & ( 1 << OCF0A))==1);		//stay here until TIFR0 is set
	TIFR0 |= ( 1 << OCF0A);				//set OCF0A to 1 in TIFR0

}

ISR(ADC_vect)
{
	velocity = ADCH;		//set velocity to ADCH 
}
